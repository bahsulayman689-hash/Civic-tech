"""
Shared Gemini client for all Gambia Civic Hub modules.

Requires the following in .streamlit/secrets.toml:

[gemini]
api_key = "YOUR_GEMINI_API_KEY"
"""

import streamlit as st
import google.generativeai as genai


@st.cache_resource
def get_gemini_model(model_name: str = "gemini-1.5-flash"):
    api_key = st.secrets["gemini"]["api_key"]
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(model_name)


def ask_gemini(prompt: str, system_instruction: str = None, model_name: str = "gemini-1.5-flash") -> str:
    """Simple single-turn call. For chat, use start_chat_session below."""
    api_key = st.secrets["gemini"]["api_key"]
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(model_name, system_instruction=system_instruction)
    response = model.generate_content(prompt)
    return response.text


def start_chat_session(system_instruction: str = None, model_name: str = "gemini-1.5-flash", history: list = None):
    """Start (or resume) a multi-turn chat session grounded with a system instruction."""
    api_key = st.secrets["gemini"]["api_key"]
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(model_name, system_instruction=system_instruction)
    return model.start_chat(history=history or [])
